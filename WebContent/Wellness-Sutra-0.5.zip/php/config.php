<?php

return array(
    // Mail Address and Name
    'sender_email'   => 'lekha.menon@niteshgroup.com',
    'sender_name'    => 'Wellness-Sutra',

    // Mail Config
    'mail_type'     => 'mail', // smtp or mail - mail is the php mail function
    'smtp_server'   => 'smtp.server.com',
    'smtp_port'     => '25',
    'smtp_user'     => 'username',
    'smtp_password' => 'xxxxxxxxxxx',

    // Mail Subjects
    'contact_form_subject' => 'New message form Welless-Sutra',
    'newsletter_form_subject' => 'New message form Welless-Sutra',
    'appointment_form_subject' => 'New appointment request form Welless-Sutra',
    'appointment_autoresponder_subject' => 'Welless-Sutra:Thanks for your appointment request',

    // Mailchimp
    'mailchimp_support' => false, // true is activated
    'mailchimp_api_key' => 'xxxxxx-your-api-key-xxxxxx',
    'mailchimp_list_id' => 'xxx-list-id-xxx',
);